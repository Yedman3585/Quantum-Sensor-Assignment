cd /home/claude/work
python3 aa_proto.py --beta 0.3 --bs 400 --max-batches 2 --first-batch 2 --tl 60 --methods greedy_ls,ils,sa,sqa,sqa_ls --ils 30 --out aa/big > aa/log_big400.txt 2>&1
