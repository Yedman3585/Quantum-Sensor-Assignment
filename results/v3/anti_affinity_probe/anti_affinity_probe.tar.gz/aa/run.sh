cd /home/claude/work
python3 aa_proto.py --beta 0.1 --max-batches 15 --first-batch 5 > aa/log_b0.1.txt 2>&1 &
python3 aa_proto.py --beta 0.3 --max-batches 15 --first-batch 5 > aa/log_b0.3.txt 2>&1 &
wait
